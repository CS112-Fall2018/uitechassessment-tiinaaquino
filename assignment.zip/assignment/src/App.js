import React from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Homepage from './Homepage';
import CartList from './CartList';
import AddItem from './AddItem';

class App extends React.Component {
  render() {
    return (
      <div className="App" >
        <Router>
          <div>

            <Route path="/" exact component={Homepage} />
            <Route path="/cartlist" component={CartList} />
            <Route path="/additem" component={AddItem} />
          </div>
        </Router>
      </div>
    );
  }
}

export default App;
