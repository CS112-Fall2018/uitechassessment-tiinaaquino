import React, { Component } from 'react';
import { Link } from "react-router-dom";

class Homepage extends Component {
  render() {
    return (
      <div>
        <button> <Link to="/cartlist">CartList</Link> </button>
        <button> <Link to="/additem">Add Item</Link></button>

        <header>
			<h1>Welcome to your cart!</h1>
			<h3>Actions:</h3>
			<p>To see the items in your cart navigate to the Cart List page.</p>
			<p>To add items to your cart navigate to the Add Item page.</p>
 		</header>
      </div>
    )
  }


}

export default Homepage;