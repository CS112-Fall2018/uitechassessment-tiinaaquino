import React from 'react';
import { Link } from "react-router-dom";

class AddItem extends React.Component {




  addItemToServer(event) {
    // We want to prevent the page refreshing when we submit the form
    event.preventDefault();
    console.log('event', event);
    // Grab the values from our input at the time of submission 
    const name = event.target.name.value;
    const description = event.target.description.value;
    const price = event.target.price.value;
    const amount = event.target.amount.value;
    console.log(name, description, price, amount);
    const item = {
      name: name,
      description: description,
      price: +price,
      amount: +amount
    }
    fetch('/item/add', {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      method: 'POST',
      body: JSON.stringify(item)
    })
    .catch(error => console.log(error.message));


  }


  render() {
    return (
      <div>
        <button> <Link to="/">Homepage</Link> </button>
        <button> <Link to="/cartlist">CartList</Link> </button>
        <br />
        <br />
        Add Item page
        <form onSubmit={this.addItemToServer}>
          <input type="text" name="name" placeholder="Name of the item" />
          <input type="text" name="description" placeholder="Description..." />
          <input type="number" name="price" placeholder="Enter price" min="0" />
          <input type="number" name="amount" placeholder="Amount" min="0" />
          <button type="submit"> Add Item </button>
        </form>

      </div>
    )
  }


}

export default AddItem;