import React from 'react';
import { Link } from "react-router-dom";



class CartList extends React.Component {
  constructor(props) {
    super(props);
    this.state = { cart: [] };
  }




  // Lifecycle hook, this function will execute when the component is rendered on to our page
  componentDidMount() {
    fetch('/list')
      .then(response => response.json())
      .then(items => this.setState({ cart: items }));
  }

  render() {
    console.log('Am I getting the cart information from my backend server? ', this.state.cart);
    return (
      <div> 
        <button> <Link to="/">Homepage</Link> </button>
        <button> <Link to="/additem">Add Item</Link></button>
        <br />
        <br />
        Cart
        
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Description</th>
              <th>Price</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            {
              this.state.cart.length > 0 && this.state.cart.map(item => (
                <tr key={item.id}>
                  <td>{item.name}</td>
                  <td>{item.description}</td>
                  <td>{item.price}</td>
                  <td>{item.amount}</td>
                </tr>
              ))
            }
          </tbody>

        </table>

      </div>
    )
  }

}

export default CartList;